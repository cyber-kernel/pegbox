import type { RunContext, RunResult } from '@pegbox/tool-kit';

// Pure function of (files, preset, options). No DOM access outside what you need, no global state,
// no network calls. Check ctx.signal.aborted in loops and between steps.
export async function run(ctx: RunContext): Promise<RunResult> {
  const [file] = ctx.files;
  ctx.onProgress('Working', 0);
  if (ctx.signal.aborted) throw new DOMException('Cancelled', 'AbortError');
  const blob = new Blob([await file.arrayBuffer()], { type: file.type || 'application/octet-stream' });
  ctx.onProgress('Done', 100);
  return { outputs: [{ name: file.name, blob, mime: blob.type }], stats: [{ label: 'Size', value: `${file.size} bytes` }] };
}
