// Optional but REQUIRED before status can be 'live': a tiny synthetic input + a pass/fail check.
// The /admin self-test page runs every tool's selfTest in the admin's own browser.
export async function makeFixture(): Promise<File[]> { return [new File(['hello'], 'hello.txt', { type: 'text/plain' })]; }
export function check(result: { outputs: { blob: Blob }[] }): string | null {
  return result.outputs.length === 1 ? null : 'expected exactly one output';
}
