import type { ToolManifest } from '@pegbox/tool-kit';

// 1) Copy this folder to tools/<your-id>/  2) edit this file  3) write engine.ts  4) run `pnpm check-tools`
export const manifest: ToolManifest = {
  id: 'your-tool-id',                 // kebab-case; becomes /tools/your-tool-id. Never rename after launch.
  name: 'Your Tool Name',
  shortName: 'Short',
  tagline: 'One plain sentence about the result the user gets.',
  description: 'One or two sentences. Used on cards and as the meta description.',
  category: 'util',
  icon: 'wand-2',                     // any Lucide icon name
  keywords: ['what people type into Google', 'online', 'free'],
  status: 'beta',                     // live | beta | hidden
  runtime: 'browser',
  input: { kind: 'any', extensions: ['txt'], maxMB: 50 },
  options: [],                        // see contracts/tool-contract.ts for slider / toggle / select / text
  presets: [{ id: 'default', name: 'Default', description: 'Good for most files.', default: true }],
  limits: ['Say honestly what this tool cannot do.'],
  faq: [{ q: 'Is my file uploaded?', a: 'No. This tool runs in your browser. Your file never leaves your device.' }],
  next: [],
  addedOn: '2026-01-01',
};
