import type { ToolModule } from '@pegbox/tool-kit';
import { manifest } from './manifest';

const tool: ToolModule = {
  manifest,
  load: () => import('./engine'),   // separate chunk: nothing downloads until the tool page opens
  // needsFfmpeg: true,             // set if the engine uses ctx.ffmpeg
};
export default tool;
