// Generates a synthetic "talking with pauses and background hiss" WAV with NO dependencies.
// Use it in unit tests, in the /admin self-test page (browser), and in CI.
// Speech-like = amplitude-modulated harmonic bursts. Pauses contain only low noise.
// MEASURED with the Node reference engine (silence-cutter, preset balanced, 12 s file, 3 pauses = 3.6 s total):
//   noise 0.005 -> removed 2.85 s, 3 cuts  (12.00 s -> 9.15 s)
//   noise 0.02  -> removed 1.35 s, 3 cuts  (12.00 s -> 10.65 s)  <- auto-threshold is weaker on noisy files
// Your browser port must land within +/-0.3 s of these numbers (same filters, same maths).
export function makeTalkingWav({ seconds = 12, rate = 48000, noise = 0.02, layout } = {}) {
  const plan = layout ?? [['talk', 3], ['pause', 1.2], ['talk', 2.5], ['pause', 1.5], ['talk', 2.9], ['pause', 0.9]];
  const n = Math.floor(seconds * rate);
  const pcm = new Int16Array(n);
  let t = 0, seed = 1234567;
  const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
  for (const [kind, len] of plan) {
    const end = Math.min(n, t + Math.floor(len * rate));
    for (let i = t; i < end; i++) {
      const s = i / rate;
      let v = noise * rnd();
      if (kind === 'talk') {
        const env = 0.5 + 0.5 * Math.sin(2 * Math.PI * 3.2 * s);               // syllable rhythm
        const f = 140 + 20 * Math.sin(2 * Math.PI * 0.7 * s);                  // pitch drift
        v += 0.35 * env * (Math.sin(2 * Math.PI * f * s) + 0.5 * Math.sin(2 * Math.PI * 2 * f * s) + 0.25 * Math.sin(2 * Math.PI * 3 * f * s)) / 1.75;
      }
      pcm[i] = Math.max(-32768, Math.min(32767, Math.round(v * 32767)));
    }
    t = end;
  }
  const buf = new ArrayBuffer(44 + n * 2), dv = new DataView(buf);
  const w = (o, s) => [...s].forEach((c, i) => dv.setUint8(o + i, c.charCodeAt(0)));
  w(0, 'RIFF'); dv.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
  dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 1, true);
  dv.setUint32(24, rate, true); dv.setUint32(28, rate * 2, true); dv.setUint16(32, 2, true); dv.setUint16(34, 16, true);
  w(36, 'data'); dv.setUint32(40, n * 2, true);
  new Int16Array(buf, 44).set(pcm);
  return new Uint8Array(buf);
}
if (import.meta.url === `file://${process.argv[1]}`) {
  const { writeFileSync } = await import('node:fs');
  writeFileSync(process.argv[2] || 'talking.wav', makeTalkingWav());
  console.log('wrote', process.argv[2] || 'talking.wav');
}
