# Creator Tools  (Hush + Cut)

Two tools, same simple workflow. Works on VIDEO (mp4, mov, mkv, avi, webm...) and AUDIO (mp3, wav, m4a...), any length.

## Setup (once)
    npm install

## 1) Voice Cleaner  - removes background noise, natural voice, louder
Put files in  voice-cleaner/assets   then run:

    npm run voice            (default, balanced)
    npm run voice:natural    (gentlest, most natural voice)
    npm run voice:strong     (maximum noise removal)

Result: voice-cleaner/out/<name>_clean.mp4 (or .mp3 for mp3 input)
Extra flags:  npm run voice -- --lufs -11   (louder)   --gain 3 (+3 dB)   --mono

## 2) Silence Cutter  - removes dead air / pauses (auto jump-cut)
Put files in  silence-cutter/assets   then run:

    npm run silence            (cuts pauses >= 0.5s)
    npm run silence:gentle     (only long pauses)
    npm run silence:fast       (fast reel / YouTuber pacing)

Result: silence-cutter/out/<name>_cut.mp4 (or .mp3 for mp3 input)
Extra flags:  npm run silence -- --threshold -40 --min-silence 0.6 --padding 0.15

## Best workflow for a raw talking video
1. npm run voice      (clean the audio)
2. copy the result from voice-cleaner/out into silence-cutter/assets
3. npm run silence    (remove the pauses)

## Use from code / a web backend
Each tool exports  run({ input, output, preset, options, onProgress })
    const hush = require('./voice-cleaner');
    await hush.run({ input: 'in.mp4', output: 'out.mp4', preset: 'balanced', onProgress: (label, pct) => {} });
Or call the CLI:  node voice-cleaner/run.js --input in.mp4 --output out.mp4 --preset strong

## Folders
    lib/            shared ffmpeg helpers
    voice-cleaner/  tool 1 (index.js = engine, run.js = batch CLI, models/ = AI denoise model)
    silence-cutter/ tool 2
    brand/          Hushcut logo files (SVG)
    tmp/            temporary files (auto-cleaned)
