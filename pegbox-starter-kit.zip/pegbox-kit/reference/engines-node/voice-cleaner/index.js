/**
 * VOICE CLEANER  - removes background noise, keeps the speaker natural, makes the voice louder.
 * Works on video (mp4, mov, mkv, ...) and audio (mp3, wav, m4a, ...) of ANY length.
 *
 *   run({ input, output, preset, options, onProgress }) -> { output, duration, summary }
 *
 * Presets
 *   natural  : gentle, most natural voice (use for already fairly clean recordings)
 *   balanced : DEFAULT. strong noise removal, voice stays natural
 *   strong   : maximum noise removal (very noisy places, fans, traffic, crowds)
 *
 * Why the voice no longer sounds echoey / broken (v2):
 *   - audio is mixed down to mono before denoising (stereo channels denoised separately cause phasey/echo sound)
 *   - the AI denoiser runs once by default (running it twice creates robotic artifacts)
 *   - FFT denoiser no longer "tracks" noise (tn=1 caused warbling) and is gentler
 *   - the noise gate is soft (reduces noise between words instead of hard-cutting it)
 *   - compressor is slower/gentler so word endings are not chopped
 */
const fs = require('fs');
const path = require('path');
const L = require('../lib/ffmpeg');

const MODEL = 'models/bd.rnnn'; // relative to this folder (ffmpeg runs with cwd = this folder)

const PRESETS = {
  natural:  { rnn: 1, mix: 0.9, fft: 'afftdn=nr=8:nf=-50',  gate: { range: 0.18, ratio: 1.5, release: 400 }, comp: 2.0 },
  balanced: { rnn: 1, mix: 1.0, fft: 'afftdn=nr=12:nf=-45', gate: { range: 0.08, ratio: 2.0, release: 350 }, comp: 2.5 },
  strong:   { rnn: 2, mix: 1.0, fft: 'afftdn=nr=18:nf=-40', gate: { range: 0.04, ratio: 4.0, release: 250 }, comp: 3.0 },
};

function buildChain(p, gateDb) {
  const thr = Math.pow(10, gateDb / 20).toFixed(5);
  const f = ['highpass=f=85', 'lowpass=f=14000'];
  for (let i = 0; i < p.rnn; i++) f.push(`arnndn=m=${MODEL}:mix=${p.mix}`);
  if (p.fft) f.push(p.fft);
  if (p.gate) f.push(`agate=threshold=${thr}:ratio=${p.gate.ratio}:attack=15:release=${p.gate.release}:range=${p.gate.range}:knee=4`);
  f.push('equalizer=f=250:t=q:w=1:g=-1.5');   // less boxiness
  f.push('equalizer=f=3200:t=q:w=1:g=2');      // voice presence / clarity
  f.push(`acompressor=threshold=-20dB:ratio=${p.comp}:attack=20:release=250:makeup=2`);
  return f.join(',');
}

/** Safer chains tried automatically if the chosen one crashes ffmpeg (seen on some Windows builds) */
function modes(presetName, gateDb) {
  const chosen = PRESETS[presetName] || PRESETS.balanced;
  return [
    { name: `${presetName}`, chain: buildChain(chosen, gateDb) },
    { name: 'balanced (1 pass)', chain: buildChain(PRESETS.balanced, gateDb) },
    { name: 'AI denoise only', chain: buildChain({ ...PRESETS.natural, fft: null, gate: null }, gateDb) },
    { name: 'FFT denoise (safe mode)', chain: ['highpass=f=85', 'afftdn=nr=25:nf=-35', 'acompressor=threshold=-20dB:ratio=2.5:attack=20:release=250:makeup=2'].join(',') },
  ];
}

async function run({ input, output, preset = 'balanced', options = {}, onProgress = () => {} }) {
  if (!PRESETS[preset]) throw new Error(`Unknown preset "${preset}". Use: natural, balanced, strong`);
  if (!(await L.hasAudio(input))) throw new Error('This file has no audio track.');

  const lufs = parseFloat(options.lufs ?? -14);
  const gainDb = parseFloat(options.gain ?? 0);
  const gateDb = parseFloat(options['gate-db'] ?? -48);
  const outChannels = options.mono ? 1 : 2;
  const audioOnly = L.isAudioFile(input);
  const duration = await L.getDuration(input);
  const tmp = L.makeTempDir();
  const rawWav = path.join(tmp, 'raw.wav');
  const cleanWav = path.join(tmp, 'clean.wav');
  const toolDir = __dirname;

  try {
    // Step 1: extract audio as 48 kHz MONO wav
    await L.ffmpeg(['-i', input, '-vn', '-map', '0:a:0', '-ac', '1', '-af', 'aresample=48000', '-ar', '48000', '-c:a', 'pcm_s16le', rawWav],
      L.progressParser(duration, (p) => onProgress('Reading audio', p)));

    // Step 2: denoise + loudness (2 pass), with automatic fallbacks
    let usedMode = null;
    for (const mode of modes(preset, gateDb)) {
      try {
        const p1 = await L.ffmpeg(['-i', rawWav, '-af', `${mode.chain},loudnorm=I=${lufs}:TP=-1.5:LRA=11:print_format=json`, '-f', 'null', '-'],
          L.progressParser(duration, (p) => onProgress('Removing noise', p)), toolDir);
        let loud = `loudnorm=I=${lufs}:TP=-1.5:LRA=11`;
        const jm = p1.stderr.match(/\{[^{}]*"input_i"[^{}]*\}/);
        if (jm) {
          try {
            const m = JSON.parse(jm[0]);
            if (isFinite(parseFloat(m.input_i))) {
              loud = `loudnorm=I=${lufs}:TP=-1.5:LRA=11:measured_I=${m.input_i}:measured_LRA=${m.input_lra}:measured_TP=${m.input_tp}:measured_thresh=${m.input_thresh}:offset=${m.target_offset}:linear=true`;
            }
          } catch {}
        }
        const gain = gainDb ? `,volume=${gainDb}dB` : '';
        await L.ffmpeg(['-i', rawWav, '-af', `${mode.chain},${loud}${gain},alimiter=limit=0.89:level=false,aresample=48000`, '-ar', '48000', '-c:a', 'pcm_s16le', cleanWav],
          L.progressParser(duration, (p) => onProgress('Boosting voice', p)), toolDir);
        usedMode = mode.name; break;
      } catch (e) { /* try next safer mode */ }
    }
    if (!usedMode) throw new Error('All noise-removal modes failed for this file.');

    // Step 3: write final file
    fs.mkdirSync(path.dirname(output), { recursive: true });
    if (audioOnly) {
      const ao = L.audioOutput(input);
      await L.ffmpeg(['-i', cleanWav, '-ar', '48000', '-ac', String(outChannels), ...ao.args, output], L.progressParser(duration, (p) => onProgress('Saving', p)));
    } else {
      await L.ffmpeg(['-i', input, '-i', cleanWav, '-map', '0:v:0?', '-map', '1:a:0', '-c:v', 'copy', '-ar', '48000', '-ac', String(outChannels),
        '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', '-shortest', output], L.progressParser(duration, (p) => onProgress('Saving', p)));
    }
    return { output, duration, mode: usedMode, summary: `Length ${L.fmtTime(duration)} | mode: ${usedMode}` };
  } finally {
    L.rmDir(tmp);
  }
}

module.exports = { run, PRESETS };
