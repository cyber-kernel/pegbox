// npm run voice            -> cleans everything in voice-cleaner/assets  -> voice-cleaner/out
// npm run voice:strong     -> maximum noise removal
// npm run voice:natural    -> gentlest, most natural
// Extra flags: --lufs -11 (louder)  --gain 3 (+3 dB)  --mono  --gate-db -45
require('../lib/ffmpeg').runCli({ toolDir: __dirname, tool: 'Voice Cleaner', suffix: '_clean', defaultPreset: 'balanced' });
