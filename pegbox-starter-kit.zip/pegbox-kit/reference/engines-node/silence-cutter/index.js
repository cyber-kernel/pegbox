/**
 * SILENCE CUTTER - removes silent gaps / dead air (auto jump-cut) from video or audio of ANY length.
 *
 *   run({ input, output, preset, options, onProgress }) -> { output, duration, newDuration, removed, summary }
 *
 * Presets
 *   gentle     : only cuts long pauses (>= 1.0s), keeps natural pacing (podcasts, tutorials)
 *   balanced   : DEFAULT. cuts pauses >= 0.5s
 *   aggressive : cuts pauses >= 0.3s, fast "YouTuber / reel" pacing
 *
 * Options: --threshold -35 (dB, silence level; default = auto-detected from the file)
 *          --min-silence 0.5   --padding 0.12   (seconds kept around speech)
 */
const fs = require('fs');
const path = require('path');
const L = require('../lib/ffmpeg');

const PRESETS = {
  gentle:     { minSilence: 1.0, padding: 0.25 },
  balanced:   { minSilence: 0.5, padding: 0.15 },
  aggressive: { minSilence: 0.3, padding: 0.08 },
};

/** auto threshold: a bit below the average loudness of the file, kept inside a safe range */
async function autoThreshold(input, duration, onProgress) {
  const r = await L.ffmpeg(['-i', input, '-vn', '-map', '0:a:0', '-af', 'highpass=f=100,volumedetect', '-f', 'null', '-'],
    L.progressParser(duration, (p) => onProgress('Analysing audio', p)));
  const mean = parseFloat((r.stderr.match(/mean_volume:\s*(-?[\d.]+) dB/) || [])[1]);
  if (!isFinite(mean)) return -35;
  return Math.max(-50, Math.min(-28, Math.round(mean - 12)));
}

async function detectSilences(input, duration, thresholdDb, minSilence, onProgress) {
  const r = await L.ffmpeg(['-i', input, '-vn', '-map', '0:a:0',
    '-af', `highpass=f=100,lowpass=f=7000,silencedetect=noise=${thresholdDb}dB:d=${minSilence}`, '-f', 'null', '-'],
    L.progressParser(duration, (p) => onProgress('Finding silences', p)));
  const silences = [];
  let start = null;
  for (const line of r.stderr.split(/\r?\n/)) {
    const s = line.match(/silence_start:\s*(-?[\d.]+)/);
    const e = line.match(/silence_end:\s*([\d.]+)/);
    if (s) start = Math.max(0, parseFloat(s[1]));
    if (e && start !== null) { silences.push([start, parseFloat(e[1])]); start = null; }
  }
  if (start !== null) silences.push([start, duration]); // silence that runs to the end
  return silences;
}

/** silences -> segments to KEEP (speech + padding) */
function keepSegments(silences, duration, padding) {
  const cuts = [];
  for (const [s, e] of silences) {
    const a = s === 0 ? 0 : s + padding;          // keep a little tail after speech
    const b = e >= duration - 0.05 ? duration : e - padding; // keep a little lead before speech
    if (b - a > 0.05) cuts.push([a, b]);
  }
  const keep = [];
  let cursor = 0;
  for (const [a, b] of cuts) {
    if (a - cursor > 0.05) keep.push([cursor, a]);
    cursor = Math.max(cursor, b);
  }
  if (duration - cursor > 0.05) keep.push([cursor, duration]);
  return keep;
}

async function run({ input, output, preset = 'balanced', options = {}, onProgress = () => {} }) {
  if (!PRESETS[preset]) throw new Error(`Unknown preset "${preset}". Use: gentle, balanced, aggressive`);
  if (!(await L.hasAudio(input))) throw new Error('This file has no audio track, so silence cannot be detected.');

  const p = PRESETS[preset];
  const minSilence = parseFloat(options['min-silence'] ?? p.minSilence);
  const padding = parseFloat(options.padding ?? p.padding);
  const audioOnly = L.isAudioFile(input);
  const duration = await L.getDuration(input);
  const tmp = L.makeTempDir();

  try {
    const thr = options.threshold !== undefined ? parseFloat(options.threshold) : await autoThreshold(input, duration, onProgress);
    const silences = await detectSilences(input, duration, thr, minSilence, onProgress);
    const keep = keepSegments(silences, duration, padding);

    if (!keep.length) throw new Error('The whole file is silent at this threshold. Try --threshold -50.');
    const removed = duration - keep.reduce((t, [a, b]) => t + (b - a), 0);
    if (removed < 0.2) {
      // nothing to cut -> copy as is
      fs.mkdirSync(path.dirname(output), { recursive: true });
      fs.copyFileSync(input, output);
      return { output, duration, newDuration: duration, removed: 0, summary: 'No silence found to remove (file copied unchanged).' };
    }

    // Build select expressions in a script file (handles thousands of cuts, any file length)
    const expr = keep.map(([a, b]) => `between(t,${a.toFixed(3)},${b.toFixed(3)})`).join('+');
    const aexpr = `aselect='${expr}',asetpts=N/SR/TB`;
    let graph, args;
    fs.mkdirSync(path.dirname(output), { recursive: true });
    const newDuration = duration - removed;

    if (audioOnly) {
      const script = path.join(tmp, 'graph.txt');
      fs.writeFileSync(script, `[0:a:0]${aexpr}[a]`);
      const ao = L.audioOutput(input);
      args = ['-i', input, '-filter_complex_script', script, '-map', '[a]', ...ao.args, output];
    } else {
      const script = path.join(tmp, 'graph.txt');
      fs.writeFileSync(script, `[0:v:0]select='${expr}',setpts=N/FRAME_RATE/TB[v];[0:a:0]${aexpr}[a]`);
      args = ['-i', input, '-filter_complex_script', script, '-map', '[v]', '-map', '[a]',
        '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p',
        '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', output];
    }
    await L.ffmpeg(args, L.progressParser(duration, (pc) => onProgress('Cutting silence', pc)));

    return {
      output, duration, newDuration, removed, cuts: silences.length,
      summary: `${L.fmtTime(duration)} -> ${L.fmtTime(newDuration)}  (removed ${L.fmtTime(removed)} of silence, ${silences.length} gaps, threshold ${thr} dB)`,
    };
  } finally {
    L.rmDir(tmp);
  }
}

module.exports = { run, PRESETS, keepSegments };
