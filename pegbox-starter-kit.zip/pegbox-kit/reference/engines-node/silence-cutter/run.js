// npm run silence             -> cuts silence from everything in silence-cutter/assets -> silence-cutter/out
// npm run silence:gentle      -> only long pauses
// npm run silence:fast        -> aggressive, fast pacing
// Extra flags: --threshold -35  --min-silence 0.5  --padding 0.12
require('../lib/ffmpeg').runCli({ toolDir: __dirname, tool: 'Silence Cutter', suffix: '_cut', defaultPreset: 'balanced' });
