# Porting the two Node engines to the browser (ffmpeg.wasm)

The Node engines in `engines-node/` are the **source of truth for behaviour** (filter chains, thresholds, maths).
They run ffmpeg as a child process. In Pegbox the same ffmpeg commands run inside **ffmpeg.wasm in a Web Worker**.
Keep every number identical. Only the plumbing changes.

## What stays identical (copy 1:1 into TypeScript, add unit tests)
- Hush: `PRESETS`, `buildChain()`, `modes()` fallback order, loudnorm target maths, output channels rule.
- Cut: `PRESETS`, `autoThreshold()` formula (`mean - 12`, clamped -50..-28), `keepSegments()`.
- Naming: `<name>_clean.<ext>` / `<name>_cut.<ext>`; video out = `.mp4`; audio out: mp3->mp3, wav->wav, else m4a.

## What changes
| Node reference | Browser port |
|---|---|
| `spawn(ffmpeg, args)` | `ffmpeg.exec(args)` (one shared FFmpeg instance inside a Worker) |
| reads stderr stream | `ffmpeg.on('log', ({message}) => ...)`. Messages arrive **line by line**: buffer them and join with `\n` before regex/JSON parsing (the loudnorm JSON block spans many lines) |
| `ffprobe` | none in wasm. Duration: `HTMLMediaElement.loadedmetadata`, or parse `Duration:` and `Stream #` lines from `ffmpeg -i file` log output. Has-audio check = any `Audio:` stream line |
| `cwd = tool folder`, `m=models/bd.rnnn` | write `bd.rnnn` into the wasm FS once (`/models/bd.rnnn`) and use the **absolute** path `arnndn=m=/models/bd.rnnn` |
| temp folder `tmp/job-*` | wasm in-memory FS. `deleteFile` every intermediate as soon as it is not needed, and `terminate()` the worker at the end so memory is returned |
| input path on disk | mount the `File` read-only (`ffmpeg.mount('WORKERFS', { files: [file] }, '/in')` in @ffmpeg/ffmpeg 0.12.x; verify against the installed version) to avoid copying a huge file into RAM |
| `progressParser` regex on `time=` | keep it (works on logs); do not rely on wasm's `progress` event alone, it is unreliable with `-f null` |

## Hush command sequence (same as Node)
1. `-i IN -vn -map 0:a:0 -ac 1 -af aresample=48000 -ar 48000 -c:a pcm_s16le raw.wav`
2. pass 1 (measure): `-i raw.wav -af "<chain>,loudnorm=I=<lufs>:TP=-1.5:LRA=11:print_format=json" -f null -`  -> parse the JSON from the buffered log
3. pass 2: `-i raw.wav -af "<chain>,loudnorm=...measured_*...:linear=true[,volume=Gain dB],alimiter=limit=0.89:level=false,aresample=48000" -ar 48000 -c:a pcm_s16le clean.wav`
4. mux. Video: `-i IN -i clean.wav -map 0:v:0? -map 1:a:0 -c:v copy -ar 48000 -ac N -c:a aac -b:a 192k -movflags +faststart -shortest out.mp4`. Audio: `-i clean.wav -ar 48000 -ac N <audioOutput args> out.ext`
If a chain throws, try the next entry of `modes()` and record which mode ran in `diagnostics.mode` (never shown to users).

## Cut command sequence (same as Node)
1. `volumedetect` pass (only if threshold is auto) -> parse `mean_volume`
2. `silencedetect` pass -> parse `silence_start` / `silence_end` lines -> `keepSegments()`
3. write `graph.txt` into the wasm FS and run with `-filter_complex_script graph.txt` (handles thousands of cuts)
   - video: `[0:v:0]select='<expr>',setpts=N/FRAME_RATE/TB[v];[0:a:0]aselect='<expr>',asetpts=N/SR/TB[a]`
   - audio: `[0:a:0]aselect='<expr>',asetpts=N/SR/TB[a]`
4. Video re-encode is the **slow part in wasm** (single thread). Start from `-preset ultrafast -crf 23`, measure, and expose a "Speed vs quality" option if needed. Report real numbers in `docs/BENCHMARKS.md`. Stretch goal if too slow: encode with WebCodecs (`VideoEncoder`) + an open-source MP4 muxer instead of libx264.
5. If nothing to remove (< 0.2 s): return the original file untouched and a stat "No silence found".

## Capability gate (Phase 0, before anything else is built)
Load the chosen ffmpeg.wasm core, run `-filters`, `-encoders`, and confirm these exist:
`arnndn afftdn agate acompressor equalizer loudnorm alimiter silencedetect volumedetect aselect select highpass lowpass volume aresample` and encoders `aac libmp3lame pcm_s16le libx264`.
If `arnndn` is missing: Plan B = build a custom core (ffmpeg.wasm publishes its build recipe) that enables it; Plan C = run RNNoise as WASM in an AudioWorklet/OfflineAudioContext in the worker, then continue with ffmpeg for the rest. Write the outcome in `DECISIONS.md`.

## Known behaviour to preserve
- Cannot remove room echo/reverb; may make it more noticeable. Say so in the FAQ. Never promise "100% noise removal".
- Cut's auto-threshold is weaker on noisy files (see `fixtures/make-fixtures.mjs`). Hush first, then Cut, gives better cuts. Offer that chain.
