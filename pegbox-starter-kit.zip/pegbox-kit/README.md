# Pegbox starter kit

Put this zip in your project folder (next to `package.json`, or in an empty folder for a new project), then tell your coding agent:

> Read `MASTER_PROMPT.md` in this kit and follow it. Start by unzipping the kit as described in section 0.

## What is inside
| Path | What it is | How the agent should treat it |
|---|---|---|
| `MASTER_PROMPT.md` | The full build plan, brand, user flow, admin flow | Follow it phase by phase |
| `brand/` | Light-theme logo SVGs, favicon set (PNG + ICO), `tokens.css` | Copy into the app; do not redraw |
| `contracts/tool-contract.ts` | The TypeScript contract every tool follows | Copy into `packages/tool-kit` |
| `templates/tool-template/` | Starter files for a new tool | Copy by script when adding tool #3, #4 ... |
| `reference/engines-node/` | The two working tools (Hush, Cut), unchanged, run with Node + ffmpeg | READ-ONLY reference for behaviour. Never import at runtime |
| `reference/PORTING_NOTES.md` | How to port them to ffmpeg.wasm | Read before Phase 3 |
| `reference/fixtures/make-fixtures.mjs` | Synthetic test audio generator + measured expected numbers | Use in tests and the admin self-test |

## Quick check of the Node reference (optional)
```
cd reference/engines-node && npm install
node voice-cleaner/run.js --input some.mp4 --output out.mp4 --preset balanced
```
